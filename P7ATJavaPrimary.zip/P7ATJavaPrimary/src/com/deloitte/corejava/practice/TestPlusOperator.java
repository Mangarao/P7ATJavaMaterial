package com.deloitte.corejava.practice;

public class TestPlusOperator {
	
	public static void main(String[] args) {
		System.out.println('H'+'I'); //HI
	}

}
