package com.deloitte.corejava.practice;

public class Operation {
	int data=50;
	public void change(Operation op) {
		op.data=op.data+50;
		System.out.println("data in change method is: "+data);
	}
	
	public static void main(String[] args) {
		Operation op=new Operation();
		System.out.println("Before change: "+op.data);
		op.change(op); //call by reference
		System.out.println("AFter change: "+op.data);
	}

}
