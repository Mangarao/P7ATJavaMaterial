package com.deloitte.corejava.practice.wrapperclasses;

public class AutoUnboxingEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Integer i=new Integer(10);
		System.out.println(i);
		int i1=i; //auto unboxing
		int i2 = i.intValue();
		System.out.println(i1);
		System.out.println(i2);
		
		Float f=new Float(10.34f);
		System.out.println(f);
		float f1=f; //auto unboxing
		float f2 = f.floatValue();
		System.out.println(f1);
		System.out.println(f2);
		
	}
	

}
