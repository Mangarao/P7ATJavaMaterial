package com.deloitte.corejava.practice.wrapperclasses;

public class AutoBoxingEx {

	public static void main(String[] args) {
		int i=10; //primitive
		Integer i1=null;
		i1=i; //auto boxing 
		Integer i2 = Integer.valueOf(i);
		System.out.println(i);
		System.out.println(i1);
		System.out.println(i2);
		
		double d=10.03;
		Double d1=d;
		Double d2 = Double.valueOf(d);
		System.out.println(d);
		System.out.println(d1);
		System.out.println(d2);
		
		
	}

}
