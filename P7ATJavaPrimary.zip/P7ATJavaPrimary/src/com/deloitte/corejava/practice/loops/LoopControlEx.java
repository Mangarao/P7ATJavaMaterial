package com.deloitte.corejava.practice.loops;

public class LoopControlEx {

	public static void main(String[] args) {
		/*
		 * for (int i = 1; i <=5; i++) { System.out.println(i+" Hello World"); }
		 */

		/*
		 * int i = 1; while (i <= 10) { System.out.println(i + " Hello World"); //i++; }
		 */

		/*
		 * int x = 10; while (x > 10) { System.out.println("Hello World"); }
		 */

		int i=1; //initialization
		
		do {
			System.out.println(i+" Hello World");
			i++; //variable change
		} while (i<=10);
	}

}
