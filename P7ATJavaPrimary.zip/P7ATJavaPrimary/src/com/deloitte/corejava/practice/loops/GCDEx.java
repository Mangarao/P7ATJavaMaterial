package com.deloitte.corejava.practice.loops;

public class GCDEx {
	
	public int getGCD(int num1, int num2) {
		int gcd=0;
		int min=num1<num2?num1:num2;
		for (int i = min;i >=0; i--) {
			if(num1%min==0 && num2%min==0) {
				gcd=min;
				break;
			}
			
		}
		return gcd;
	}
	
	public static void main(String[] args) {
		GCDEx g=new GCDEx();
		System.out.println(g.getGCD(16,64));
	}

}
