package com.deloitte.corejava.practice.loops;

public class PrimeNo {

	public boolean isPrime(int num) {
		for (int i = 2; i <=Math.sqrt(num); i++) {
			if (num % i == 0) {
				return false;
			}
		}
		
		return true;
	}
	
	public void printPrimes(int range) {
		int count=0;
		for (int i = 2; i <=range ; i++) {
			if(isPrime(i)) {
				++count;
				System.out.print(i+"\t");
			}
			
		}
		System.out.println("\nNo. of primes: "+count);
		
	}
	

	public static void main(String[] args) {
		PrimeNo p=new PrimeNo();
		p.printPrimes(1000);

	}
}