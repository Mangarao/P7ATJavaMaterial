package com.deloitte.corejava.practice.loops;

public class ForEachDemo {
	
	public static void main(String[] args) {
		String[] names= {"Manga", "Mihiraan", "Aarohi", "Sireesha"};
		
		/*
		 * for (int i = 0; i < names.length; i++) { System.out.println(names[i]);
		 * 
		 * }
		 */
		
		for (String name : names) {
			if(name.equals("Aarohi")) {
				continue; 
			}
			System.out.println(name);
		}
		System.out.println("Rest of the code");
	}

}
