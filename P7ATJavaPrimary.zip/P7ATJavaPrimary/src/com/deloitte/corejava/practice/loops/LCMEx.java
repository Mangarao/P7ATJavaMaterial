package com.deloitte.corejava.practice.loops;

public class LCMEx {
	
	public int getLCM(int num1, int num2) {
		int lcm=0;
		//logic
		int max=num1>num2?num1:num2;
		while(true) {
			if(max%num1==0 && max%num2==0) {
				lcm=max;
				break;
			}
			max++;
		}
		return lcm;
	}
	
	public static void main(String[] args) {
		LCMEx l=new LCMEx();
		System.out.println(l.getLCM(4, 7));
		
	}

}
