package com.deloitte.corejava.practice.loops;

public class ForLoopEx {
	
	public static void main(String[] args) {
		for(int x=10;x<10 ;x++) {
			System.out.println("Happy Children's Day");
		}
			System.out.println("Statement 2");
	}

}
