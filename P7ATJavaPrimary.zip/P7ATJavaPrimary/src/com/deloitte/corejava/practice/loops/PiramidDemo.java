package com.deloitte.corejava.practice.loops;

public class PiramidDemo {
	public static void main(String[] args) {
		for (int i = 5; i >=1; i--) {
			System.out.println((i+" ").repeat(i));
			/*
			 * for (int j = 1; j <= i; j++) { System.out.print("*\t"); }
			 * System.out.println();
			 */
		}
		
	}

}
