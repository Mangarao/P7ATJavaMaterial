package com.deloitte.corejava.practice.loops;

public class EvenOdd {
	
	public static void main(String[] args) {
		for (int i = 1; i <=20; i+=2) {
			//if(i%2!=0) {
				System.out.print(i+"\t");
			//}
			
		}
	}

}
