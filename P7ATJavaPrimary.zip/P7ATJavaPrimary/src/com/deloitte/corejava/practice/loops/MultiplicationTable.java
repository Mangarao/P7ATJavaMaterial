package com.deloitte.corejava.practice.loops;

public class MultiplicationTable {

	public void printTable(int num) {
		for (int i = 1; i <= 10; i++) {
			System.out.println(num + " * " + i + " = " + (num * i));
		}
	}

	public static void main(String[] args) {
		MultiplicationTable mt = new MultiplicationTable();
		mt.printTable(10);
		System.out.println("***************");
		mt.printTable(5);
	}

}
