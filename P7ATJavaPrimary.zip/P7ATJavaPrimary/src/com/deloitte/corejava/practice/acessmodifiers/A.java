package com.deloitte.corejava.practice.acessmodifiers;

public class A {

	 public A() {
		
	}
	public  int data = 50;

	 public void msg() {
		System.out.println("Australia vs SA semi final match has interrupted due to unexpected rain...");
	}
	
	public static void main(String[] args) {
		A a=new A();
		System.out.println(a.data);
		a.msg();
	}

}
