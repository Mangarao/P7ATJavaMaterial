package com.deloitte.corejava.practice.acessmodifiers;

public class TestA {
	
	
	public static void main(String[] args) {
		A a=new A();
		a.msg();
		System.out.println(a.data);
	}

}
