package com.deloitte.corejava.practice.java8;

public interface MyInterface {
	
	
	
	public abstract void m1();
	public abstract void m2();
	public default void m3() {
		System.out.println("This is m3 method");
	}
	
	public default void m4() {
		System.out.println("This is m3 method");
	}
	
	public static void m5() {
		System.out.println("This is static method");
	}
	
	

}
