package com.deloitte.corejava.practice.java8;

interface ICC {
	void printScore();

	void getScore();
}

public class TestClass {

	//single line comment
	public static void main(String[] args) {
		ICC i = new ICC() {

			/*
			 * this is the multi line comment example
			 * this printscore method is overriden to print score
			 */
			@Override
			public void printScore() {
				System.out.println("India is on top with 18 points");

			}

			/**
			 * what ever you write here, it is captured under documentation
			 * 
			 */
			@Override
			public void getScore() {
				System.out.println("Current SA score is 100+");

			}

		};
		i.printScore();
		i.getScore();

		new Runnable() {

			@Override
			public void run() {
				System.out.println("My thread is running");

			}
		}.run();

		Runnable r = () -> System.out.println("Bahubali thread is running");
		r.run();
	}

}
