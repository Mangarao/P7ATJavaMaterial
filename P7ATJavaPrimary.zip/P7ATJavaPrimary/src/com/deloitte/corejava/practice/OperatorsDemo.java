package com.deloitte.corejava.practice;

public class OperatorsDemo {
	public static void main(String[] args) {
		 int num = 5;

	        // Step 2: Post-increment and print
	        System.out.println("Original Value: " + num); //5
	        System.out.println("Post-increment Result: " + (num++)); // 5 Post-increment

	        // Step 3: Pre-increment and print
	        System.out.println("Pre-increment Result: " + (++num)); //7 Pre-increment

	        // Step 4: Print current value
	        System.out.println("Current Value: " + num); //7
		/* int a=10; int b=++a; //a=11 //++a pre increment //a++ post increment
		 * System.out.println(++b);//12 System.out.println(--a); //10
		 */	}

}
