package com.deloitte.corejava.practice;

import java.util.Scanner;

public class SwitchDemo {
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the grade (A/B/C/D): ");
        char grade = scanner.next().toUpperCase().charAt(0);
        switch (grade) {
		case 'A':
			System.out.println("Result is Distinction");
			break;
		case 'B':
			System.out.println("Result is Good");
			break;
		case 'C':
				System.out.println("Result is average");
				break;
		case 'D':
				System.out.println("Result is Fail");
				break;

		default:
			System.out.println("Invalid Grade");
		}
        System.out.println("Program execution is complete");
	}

}
