package com.deloitte.corejava.practice;

public class OperatorPrecedenceEx {
	
	public static void main(String[] args) {
		int result = ((5 + 3) * 2) / (4 - 1);
		System.out.println("Result is: "+result);
	}

}
