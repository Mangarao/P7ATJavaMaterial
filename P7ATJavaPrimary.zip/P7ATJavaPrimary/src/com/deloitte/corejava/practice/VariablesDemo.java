package com.deloitte.corejava.practice;

public class VariablesDemo {
	
	int x=10; //instance variable
	static int y=20; //static variable is class level
	void m1() {
		int z=20; //local variable
	}
	

}

//"Hardwork never fails"