package com.deloitte.corejava.practice;

public class HelloWorld {
	String _345544ame;
	public static void main(String... amr) {
		System.out.println("Hello, Welcome to Java world");
	}

}
