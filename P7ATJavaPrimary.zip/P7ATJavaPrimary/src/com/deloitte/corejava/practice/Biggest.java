package com.deloitte.corejava.practice;

public class Biggest {

	public static void main(String[] args) {
		int num1 = 1000, num2 = 100, num3 = 200;

		if (num1 > num2 && num1 > num3) {
			System.out.println("Num1 is big");
		} else if (num2 > num3) {
			System.out.println("Num2 is big");
		} else {
			System.out.println("num3 is big");
		}
	}

}
