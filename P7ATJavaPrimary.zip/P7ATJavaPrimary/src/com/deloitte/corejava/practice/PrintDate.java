package com.deloitte.corejava.practice;

import java.text.SimpleDateFormat;

//import java.util.Date;

public class PrintDate {
	

	
	public static void main(String[] args) {
		java.util.Date d =new java.util.Date();
		
		System.out.println(d);
		System.out.println(d.getDate()+"-"+(d.getMonth()+1)+"-"+(d.getYear()+1900));
		
		SimpleDateFormat sd=new SimpleDateFormat("dd/MMM/YY hh:mm:ss");
		String dateFormat = sd.format(d);
		System.out.println("Formatted date is: "+dateFormat);
		System.out.println(d.getTime());
	}

}
