package com.deloitte.corejava.practice;

public class RecursionDemo {
	static int counter=0;
	void printName() {
		System.out.println("AMR");
		++counter;
		if(counter<3) {
			printName();
		}
		
	}
	
	public static void main(String[] args) {
		System.out.println("main method is called");
		if(++counter<3) {
			//recursion
			main(new String[] {"AMR","Manga"});
		}
		/*
		 * RecursionDemo rd=new RecursionDemo(); rd.printName();
		 */
		//3! = 3X2X1 = 6
		//4! = 4X3X2X1 =24
		
	}

}
