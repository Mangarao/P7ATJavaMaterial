package com.deloitte.corejava.practice.strings;

public class StringBufferEx {
	
	
	public static void main(String[] args) {
		//StringBuffer is mutable
		StringBuffer sb=new StringBuffer("Sachin");
		sb.append(" Tendulkar");
		System.out.println(sb);
		System.out.println(sb.length());
		System.out.println(sb.replace(0,6,"Arjun"));
	}

}
