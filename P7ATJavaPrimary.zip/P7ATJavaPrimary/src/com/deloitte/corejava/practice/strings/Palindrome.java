package com.deloitte.corejava.practice.strings;

public class Palindrome {
	
	public boolean isPalindrome(String name) {
		return new StringBuilder(name).reverse().toString().equals(name);
	}
	
	public static void main(String[] args) {
		Palindrome p=new Palindrome();
		System.out.println(p.isPalindrome("ANNA"));
	}

}
