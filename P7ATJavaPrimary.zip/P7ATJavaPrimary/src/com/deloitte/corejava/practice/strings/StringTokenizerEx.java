package com.deloitte.corejava.practice.strings;

public class StringTokenizerEx {
	
	public static void main(String[] args) {
		String name="My~name~is~Manga~Rao~Arepalli";
		/*
		 * StringTokenizer sb=new StringTokenizer(name,"~"); while(sb.hasMoreElements())
		 * { System.out.println(sb.nextElement()); }
		 */
		String[] tokens = name.split("~");
		for (String name1 : tokens) {
			System.out.println(name1);
		}
	}

}
