package com.deloitte.corejava.practice.strings;

public class StringEx {
	public static void main(String[] args) {
		/*
		 * char[] names= {'M','A','N','G','A'}; String name=new String(names);
		 */
		//String name=new String("Dhoni");
		String name="Virat Kohli";
		System.out.println(name);
		System.out.println("Length of the string: "+name.length());
		System.out.println(name.charAt(0));
	}

}
