package com.deloitte.corejava.practice;

public class InstanceOfDemo {
	public static void main(String[] args) {
		String name="Mihiraan";
		System.out.println(name instanceof String);
		name=null;
		System.out.println(name instanceof String);
		String names[]= {"Manga", "Mihirran", "Aarohi", "Siri"};
		System.out.println(names instanceof Object[]); 
	}
}
