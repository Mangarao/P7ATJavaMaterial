package com.deloitte.corejava.practice.arrays;

import java.util.Arrays;

public class TestArray {

	public static void main(String[] args) {
			String names[]= {"Manga", "Dhoni", "Virat"};
			Arrays.sort(names);
			for (String name : names) {
				System.out.println(name);
			}
	}

}
