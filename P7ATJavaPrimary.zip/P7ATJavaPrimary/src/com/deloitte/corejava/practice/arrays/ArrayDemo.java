package com.deloitte.corejava.practice.arrays;

import java.util.Arrays;

public class ArrayDemo {
	
	public static void main(String[] args) {
		/*
		 * int[] nums=new int[5]; nums[0]=10; nums[1]=20; nums[3]=5; nums[2]=-10;
		 * nums[4]=25;
		 */
		
		int[] nums= {10,-20,5,500,100};
		
		//print array elements in sorted order
		Arrays.sort(nums);
		
		for (int i = nums.length-1; i>=0; i--) {
			System.out.println(nums[i]);
		}
		/*
		 * for (int i = 0; i < nums.length; i++) { System.out.println(nums[i]); }
		 */
	}

}
