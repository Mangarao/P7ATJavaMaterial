package com.deloitte.corejava.practice;

public class LiteralsEx {

	public static void main(String[] args) {
		System.out.print("Hello Dude,  ");
		System.out.print("How are you doing?");
		/*
		 * System.out.println("\"Hardwork never fails..\"");
		 * System.out.println("\"Jukegha nahi hain..\"");
		 */
	}

}
