package com.deloitte.corejava.practice;

import com.deloitte.corejava.practice.acessmodifiers.A;

public class TestA {
	public static void main(String[] args) {
		A a=new A();
		a.msg();
		System.out.println(a.data);
	}

}
