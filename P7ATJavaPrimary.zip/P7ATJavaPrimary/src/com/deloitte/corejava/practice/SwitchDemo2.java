package com.deloitte.corejava.practice;

public class SwitchDemo2 {

	public static void main(String[] args) {
		String acronym = "MSD";
		switch (acronym) {
		case "AMR":
			System.out.println("Arepalli Manga Rao");
			break;
		case "MSD":
			System.out.println("Mahindra Singh Dhoni");
			break;
		case "VK":
			System.out.println("Virat Kohli");

		}
	}

}
