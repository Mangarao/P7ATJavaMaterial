package com.deloitte.corejava.practice;

public class HiWorld {
	
	public static void main(String[] args) {
		System.out.println("Manga has 10+years of IT experience, working as a Manager");
		System.out.println("He is from Vijaywada, staying in Hyderabad");
		System.out.println("His Deloitte Base location is Hyderabad");
		System.out.println("He is Java faculty in DTA ");
		
		
	}

}
