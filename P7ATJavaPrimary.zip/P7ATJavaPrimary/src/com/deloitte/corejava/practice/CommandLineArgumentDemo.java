package com.deloitte.corejava.practice;

public class CommandLineArgumentDemo {
	
	public static void main(String[] myargs) {
		System.out.println("Length of the args is: "+myargs.length);
		for (String value : myargs) {
			System.out.println(value);
		}
	}

}
