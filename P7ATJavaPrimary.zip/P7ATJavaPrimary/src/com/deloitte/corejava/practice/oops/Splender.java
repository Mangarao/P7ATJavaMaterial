package com.deloitte.corejava.practice.oops;

class Bike2{
	int speedlimt=90;
	public void run() {
		System.out.println("Bike is running");
	}
	
	/*
	 * public void drive() {
	 * 
	 * }
	 */
	
}


public class Splender extends Bike2 {
	int speedlimit=150; //Field hiding...
	@Override
	public void run() {
		System.out.println("Splender is running smoothly with 60km mileage");
	}
	public void drive() {
		System.out.println("You are driving the splender bike");
	}
	
	public static void main(String[] args) {
		Splender s=new Splender(); //R.T polymorphism 
		System.out.println(s.speedlimt);
	}

}
