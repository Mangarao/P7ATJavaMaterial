package com.deloitte.corejava.practice.oops;

public class Employee implements Cloneable {

	private int id;
	private String name;

	public Employee() {

	}

	public Employee(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() { // TODO Auto-generated method stub
		return id + " " + name;
	}
	
	@Override
	protected Object clone() throws CloneNotSupportedException {
		// TODO Auto-generated method stub
		return super.clone();
	}
	
	public static void main(String[] args)  {
		Employee e1 = new Employee(101, "Manga");
		System.out.println(e1);
		try {
			Employee e2 = (Employee) e1.clone();
			System.out.println(e2);
		} catch (CloneNotSupportedException e) {
			System.err.println("CLone not supported exception occured, please implement Cloneable interface");
		}
		System.out.println("Rest of code");
	}

}
