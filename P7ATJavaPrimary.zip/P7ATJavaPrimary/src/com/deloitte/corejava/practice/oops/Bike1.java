package com.deloitte.corejava.practice.oops;

 class Vehicle{
	
	Vehicle(){
		
	}
	Vehicle(int speed){
		System.out.println("Vehicle is created with speed: "+speed);
	}
	
	int speed=50;
	public  void run() {
		System.out.println("Vehicle is running...");
	}
	
}
public class Bike1 extends Vehicle {
	Bike1(int speed){
		
	}
	Bike1(){
		super(60);//calling super class constructor
		System.out.println("Bike is created.. this child constructor");
	}
	

	int speed=100;
	@Override
	public void run() {
		
		System.out.println("Bike is running with speed.."+super.speed);
		
	}
	
	public static void main(String[] args) {
		Bike1 b=new Bike1();
		b.run();
	}

}
