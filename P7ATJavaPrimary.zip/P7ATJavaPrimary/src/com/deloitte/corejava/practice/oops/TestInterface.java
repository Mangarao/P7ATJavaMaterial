package com.deloitte.corejava.practice.oops;


public class TestInterface implements Showable {
	

	public static void main(String[] args) {
		TestInterface t=new TestInterface();
		t.print();
		t.show();
		System.out.println(TestInterface.PI);
			
	}
	
	@Override
	public void print() {
		System.out.println("Congrats.. Team India entered into ICC WORLD CUP FINAL, 2023");
		
	}

	@Override
	public void show() {
		System.out.println("all the best Team India for Final.. Hope we will have a good and memorable show");
		
	}

}
