package com.deloitte.corejava.practice.oops;

abstract class Scooty{
	Scooty(){
		System.out.println("abstract class constructor..");
	}
	abstract void run();
	void drive() {
		System.out.println("Scotty is driven...");
	}
}

public class Honda extends Scooty {
	
	public static void main(String[] args) {
		Scooty s=new Honda(); //R.T polymorphism
		s.run();
	}

	@Override
	void run() {
	System.out.println("Honda scooty is running safely without gear system..");
		
	}

}
