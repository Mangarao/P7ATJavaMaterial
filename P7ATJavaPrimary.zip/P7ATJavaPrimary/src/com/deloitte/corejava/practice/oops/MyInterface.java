package com.deloitte.corejava.practice.oops;

public interface MyInterface {
	
	
	//Marker or Tagged Interface...

}
