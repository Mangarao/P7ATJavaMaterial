package com.deloitte.corejava.practice.oops;
class Address{
	
	private String city;
	private String state;
	private String country;
	public Address(String city, String state, String country) {
		super();
		this.city = city;
		this.state = state;
		this.country = country;
	}
	@Override
	public String toString() {
		return "Address [city=" + city + ", state=" + state + ", country=" + country + "]";
	}
	

}
public class Employee2 {
	
	private int id;
	private String name;
	private Address address;
	public Employee2(int id, String name, Address address) {
		super();
		this.id = id;
		this.name = name;
		this.address=address;
	}

	
	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", address=" + address + "]";
	}


	public static void main(String[] args) {
		Address a=new Address("Hyderabad","TS", "India");
		Employee2 e1=new Employee2(101, "Manga", a);
		System.out.println(e1);
		
	}
	
	
	

}
