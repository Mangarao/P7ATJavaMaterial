package com.deloitte.corejava.practice.oops;
class A{
	
}

class B{
	
}
public class Calculator {
	
	void m1() {
		System.out.println("M1 method...");
	}
	
	public void sum(String name, int... nums) {
		int sum=0;
		for (int i : nums) {
			sum+=i;
		}
		System.out.println("Sum is: "+sum);
		m1();
	}
	
	public static void main(String... args) {
		Calculator c=new Calculator();
		c.sum("Manga", 10,20);
	}

}
