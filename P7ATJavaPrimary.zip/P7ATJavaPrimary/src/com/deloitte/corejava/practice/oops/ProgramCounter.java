package com.deloitte.corejava.practice.oops;

 class ProgramCounter {
	 
	
	
	static int counter=0;
	
	public ProgramCounter() {
		System.out.println(++counter);
	}
	public static int cube(int num) {
	
		return num*num*num;
		
	}
	
	 static int x;
	 
	 static {
		 System.out.println("Static block is executed");
		 x=10;
	 }
	 
	 {
		 
	 }
	
	public static void main(String[] args) {
		
		System.out.println("Main method is executed");
		ProgramCounter p1=new ProgramCounter();
		ProgramCounter p2=new ProgramCounter();
		ProgramCounter p3=new ProgramCounter();
		System.out.println(cube(3));
		
		System.out.println(x);
	}

}
