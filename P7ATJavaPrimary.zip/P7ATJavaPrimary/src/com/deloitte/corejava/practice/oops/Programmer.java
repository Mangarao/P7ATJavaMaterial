package com.deloitte.corejava.practice.oops;
class Employee1{
	
	int salary=40000;
	
	public void m1() {
		System.out.println("m1 method");
	}
	
}
public class Programmer extends Employee1{
	int bonus=10000;
	public static void main(String[] args) {
		Programmer p=new Programmer();
		System.out.println("Net salary: "+(p.salary+p.bonus));
		p.m1();
	}
	
	

}
