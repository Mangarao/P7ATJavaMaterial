package com.deloitte.corejava.practice.oops;

public class Bike {
	
	public static final double PI=3.14;
	
	final int speed=150;
	Bike(){
		//speed=150;
		
		System.out.println("Bike speed is :"+speed);
	}
	
	{
		System.out.println("instance block is called");
		//speed=100;
	}
	{
		System.out.println("Instance block2 is called");
	}
	static{
		System.out.println("static block is called");
	}
	
	public static void main(String[] args) {
		System.out.println("main method is called");
		Bike b=new Bike();
	}

}
