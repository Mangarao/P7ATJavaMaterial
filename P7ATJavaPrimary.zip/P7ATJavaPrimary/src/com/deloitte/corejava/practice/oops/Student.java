package com.deloitte.corejava.practice.oops;

public class Student {
	
	private int id;
	private String name;
	
	Student(){
		this(101, "Mnaga");
		System.out.println("Student default constructor");
	}
	
	Student(int id, String name){
		this.id=id;
		this.name=name;
		
	}
	public int getId() {
		return id;
	}
	public void setId(final int id) {
		
		this.id = id;
	}

	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public static void main(String[] args) {
		Student s1=new Student();
		System.out.println(s1.getId()+" "+s1.getName());
		
	}

}
