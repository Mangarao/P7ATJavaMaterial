package com.deloitte.corejava.practice.oops;

public interface Showable extends Printable{
	
	public abstract void show();

}
