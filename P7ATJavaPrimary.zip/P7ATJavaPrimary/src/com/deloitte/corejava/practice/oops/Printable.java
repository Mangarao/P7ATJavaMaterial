package com.deloitte.corejava.practice.oops;

public interface Printable {
	
	
	public static final double PI=3.14;
	
	public abstract void print(); 

}
