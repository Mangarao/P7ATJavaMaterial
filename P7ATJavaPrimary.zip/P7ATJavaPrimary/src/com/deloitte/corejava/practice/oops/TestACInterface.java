package com.deloitte.corejava.practice.oops;
interface I{
	void a();
	void b();
	void c();
	void d();
}

abstract class AC implements I{
	public void c() {
		System.out.println("c method");
	}
}

class MyClass extends AC{

	@Override
	public void a() {
		System.out.println("a method");
		
	}

	@Override
	public void d() {
		System.out.println("d method");
		
	}

	@Override
	public void b() {
		System.out.println("b method");
		
	}
	
}

public class TestACInterface {
	
	public static void main(String[] args) {
		
		I i = new MyClass();
		i.a(); i.b(); i.c(); i.d();
		
	}

}
