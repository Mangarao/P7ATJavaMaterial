package com.deloitte.corejava.practice.oops;
class Bank{
	public double getRateOfInterest() {
		return 0;
	}
}

class ICICI extends Bank{
	@Override
	public double getRateOfInterest() {
		return 8.5;
	}
}

class Axis extends Bank{
	@Override
	public double getRateOfInterest() {
		return 7.5;
	}
}

class SBI extends Bank{
	@Override
	public double getRateOfInterest() {
		return 7;
	}
}
public class TestBank {
	
	public static void main(String[] args) {
		Bank i=new ICICI();
		System.out.println("ICICI rate of interest is: "+i.getRateOfInterest()+"%");
		Bank a=new Axis();
		System.out.println("AXIS rate of interest is: "+a.getRateOfInterest()+"%");
		Bank s=new SBI();
		System.out.println("SBI rate of interest is: "+s.getRateOfInterest()+"%");
	}

}
