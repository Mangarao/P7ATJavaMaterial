package com.deloitte.corejava.practice;

public class IfDemo {

	public static void main(String[] args) {
		int x = 10;
		if (x == 10)
		System.out.println("statement1");

		System.out.println("Statement2");
	}

}
