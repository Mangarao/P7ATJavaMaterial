package com.deloitte.corejava.practice;

public class TestCube {
	
	public static void main(String[] args) {
		Cube c1=new Cube();
		System.out.println("Cube of 6 is: "+c1.getCube(6));
	}

}
