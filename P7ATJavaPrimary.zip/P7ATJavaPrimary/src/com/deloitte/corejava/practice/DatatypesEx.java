package com.deloitte.corejava.practice;

public class DatatypesEx {
	
	static int i=10; 
	static double d=10.24f;
	static float f=10.23F;
	static boolean bo=true;
	static String name="Manga";
	public static void main(String[] args) {
		System.out.println("i is: "+i);
		System.out.println("boolean default value: "+bo);
		System.out.println("Float default value: "+f);
		System.out.println("Double default value: "+d);
		System.out.println("Default value for String: "+name);
	}

}
