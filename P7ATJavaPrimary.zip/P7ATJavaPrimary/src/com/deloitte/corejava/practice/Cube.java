package com.deloitte.corejava.practice;

public class Cube {
	/*
	 * This is the method to return
	 * cube of the given number
	 */
	public  int getCube(int num) {
		return num*num*num;
	}
	public static void main(String[] args) {
		Cube c=new Cube();
		System.out.println("cube of  4 is "+c.getCube(4));
		System.out.println("cube of 5 is "+c.getCube(5));
		System.out.println("cube of 6 is "+c.getCube(6));
		
	}

}
