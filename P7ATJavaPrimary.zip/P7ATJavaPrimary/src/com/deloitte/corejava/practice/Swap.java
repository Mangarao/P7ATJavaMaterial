package com.deloitte.corejava.practice;

import java.util.Scanner;

public class Swap {
	
	public static  void swap(int num1, int num2) {
		System.out.println("Before swapping...");
		System.out.println("num1= "+num1+" num2="+num2);
		//logic here
		//swapping logic with third variable
		//swapping logic without third variable
		/*
		 * int temp=num1; num1=num2; num2=temp;
		 */
		/*
		 * num1=num1+num2; num2=num1-num2; num1=num1-num2;
		 */
		num2=(num1+num2) - (num1=num2);
		/*
		 * num1=num1^num2; num2=num1^num2; num1=num1^num2;
		 */
		
		System.out.println("After swapping...");
		System.out.println("num1= "+num1+" num2="+num2);
	}
	
	public static void main(String[] args) {
		//attached console to the scanner
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number 1");
		int num1 = sc.nextInt();
		System.out.println("Enter number 2");
		int num2 = sc.nextInt();
		swap(num1, num2); 
	}

}
