package com.deloitte.corejava.practice;
class Parent{
	
	protected void msg() {
		System.out.println("Parent class method");
	}
}
public class Kid extends Parent {
	
	 public void msg() {
		// TODO Auto-generated method stub

	}
	
	public static void main(String[] args) {
		
	}

}
