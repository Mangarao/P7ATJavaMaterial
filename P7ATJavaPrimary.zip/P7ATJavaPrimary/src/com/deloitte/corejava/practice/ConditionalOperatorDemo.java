package com.deloitte.corejava.practice;

public class ConditionalOperatorDemo {
	
	public static void main(String[] args) {
		int num1=100, num2=500;
		/*
		 * int bigger = (num1>num2)?num1:num2;
		 * System.out.println("Bigger no. is: "+bigger);
		 */
		System.out.println("Bigger is: "+(num1>num2?num1:num2));
		System.out.println("Smaller is: "+(num1<num2?num1:num2));
	}

}
