package com.deloitte.corejava.practice;

import java.util.Scanner;

public class GradingResult {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the grade (A/B/C/D): ");
        char grade = scanner.next().toUpperCase().charAt(0);

        if (grade == 'A') {
            System.out.println("Result: Distinction");
        } else if (grade == 'B' ) {
            System.out.println("Result: Good");
        } else if (grade == 'C') {
            System.out.println("Result: Average");
        } else if (grade == 'D') {
            System.out.println("Result: Fail");
        } else {
            System.out.println("Result: Invalid grade");
        }
    }
}
